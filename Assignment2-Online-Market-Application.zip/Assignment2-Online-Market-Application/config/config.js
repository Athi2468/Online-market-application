module.exports = {
  ATLASDB: "mongodb+srv://anaran21:Abhishek2585@cluster0.zwdnrhy.mongodb.net/?retryWrites=true&w=majority",
};
